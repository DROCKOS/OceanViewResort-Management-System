package com.oceanview.service;

import com.oceanview.dao.AuditLogDAO;
import com.oceanview.dao.RoomDAO;
import com.oceanview.model.Room;

import java.util.List;

public class RoomService {

    private RoomDAO roomDAO = new RoomDAO();
    private AuditLogDAO auditLogDAO = new AuditLogDAO();

    public List<Room> getAllRooms() {
        return roomDAO.getAllRooms();
    }

    public List<Room> getAvailableRooms(String checkIn, String checkOut) {
        return roomDAO.getAvailableRooms(checkIn, checkOut);
    }

    public Room getRoomById(int roomId) {
        return roomDAO.getRoomById(roomId);
    }

    public String addRoom(String roomNumber, String roomType, double pricePerNight,
                          String description, String roomSize, int numBeds,
                          int maxPersons, String imageUrl, int userId) {
        if (roomNumber == null || roomNumber.trim().isEmpty()) return "Room number is required";
        if (roomType == null || roomType.trim().isEmpty()) return "Room type is required";
        if (pricePerNight <= 0) return "Price must be greater than zero";

        Room room = new Room();
        room.setRoomNumber(roomNumber.trim());
        room.setRoomType(roomType.trim());
        room.setPricePerNight(pricePerNight);
        room.setDescription(description);
        room.setRoomSize(roomSize);
        room.setNumBeds(numBeds);
        room.setMaxPersons(maxPersons);
        room.setImageUrl(imageUrl);
        room.setAvailable(true);

        boolean success = roomDAO.addRoom(room);
        if (success) {
            auditLogDAO.log(userId, "ADD_ROOM", "Added room " + roomNumber + " (" + roomType + ")");
            return "SUCCESS";
        }
        return "Failed to add room";
    }

    public String updateRoom(int roomId, String roomType, double pricePerNight,
                             String description, boolean isAvailable, String roomSize,
                             int numBeds, int maxPersons, String imageUrl, int userId) {
        Room room = roomDAO.getRoomById(roomId);
        if (room == null) return "Room not found";

        room.setRoomType(roomType);
        room.setPricePerNight(pricePerNight);
        room.setDescription(description);
        room.setAvailable(isAvailable);
        room.setRoomSize(roomSize);
        room.setNumBeds(numBeds);
        room.setMaxPersons(maxPersons);
        room.setImageUrl(imageUrl);

        boolean success = roomDAO.updateRoom(room);
        if (success) {
            auditLogDAO.log(userId, "UPDATE_ROOM", "Updated room " + room.getRoomNumber());
            return "SUCCESS";
        }
        return "Failed to update room";
    }
}